import os
import time
import json
import uuid
import re
import sqlite3
from datetime import datetime, timezone

import requests
from flask import Flask, jsonify, request, send_from_directory
from railway_deploy import get_deploy_manager
import logging

app = Flask(__name__, static_folder="static", static_url_path="")
logger = logging.getLogger(__name__)

PORT = int(os.getenv("PORT", "8080"))

# Public/API protection (optional)
K1_API_TOKEN = os.getenv("K1_API_TOKEN", "")          # header: X-API-Token
# Admin protection (required for admin endpoints)
K1_ADMIN_TOKEN = os.getenv("K1_ADMIN_TOKEN", "")      # header: X-Admin-Token
DEPLOY_API_KEY = os.getenv('DEPLOY_API_KEY', '')  # Authorization: Bearer <key>

# OpenAI (AI + Web Search + STT + TTS)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5")
OPENAI_REASONING_EFFORT = os.getenv("OPENAI_REASONING_EFFORT", "low")

OPENAI_TTS_MODEL = os.getenv("OPENAI_TTS_MODEL", "tts-1")
OPENAI_TTS_VOICE = os.getenv("OPENAI_TTS_VOICE", "onyx")  # male default
OPENAI_STT_MODEL = os.getenv("OPENAI_STT_MODEL", "whisper-1")

DB_PATH = os.getenv("K1_DB_PATH", os.path.join("data", "k1.db"))
AUDIO_DIR = os.path.join(app.root_path, "static", "audio")

DEFAULT_LANGUAGE = "en"
PERSONA_STYLE = "friendly_conversational"

# Optional source allowlist for web-search sources (comma-separated domains)
K1_SOURCE_ALLOWLIST = os.getenv('K1_SOURCE_ALLOWLIST', '')

# --- auth helpers ---
def _auth_ok(req) -> bool:
    if not K1_API_TOKEN:
        return True
    return req.headers.get("X-API-Token", "") == K1_API_TOKEN

def _admin_ok(req) -> bool:
    if not K1_ADMIN_TOKEN:
        return False
    return req.headers.get("X-Admin-Token", "") == K1_ADMIN_TOKEN

# --- time/db helpers ---
def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(AUDIO_DIR, exist_ok=True)
    with db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                profile_json TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL,
                meta_json TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS audit (
                id TEXT PRIMARY KEY,
                ts TEXT NOT NULL,
                user_id TEXT,
                session_id TEXT,
                action TEXT NOT NULL,
                detail_json TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS leads (
                id TEXT PRIMARY KEY,
                ts TEXT NOT NULL,
                name TEXT,
                email TEXT,
                message TEXT
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS summaries (
                user_id TEXT PRIMARY KEY,
                updated_at TEXT NOT NULL,
                summary TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id TEXT PRIMARY KEY,
                ts TEXT NOT NULL,
                user_id TEXT,
                session_id TEXT,
                message_id TEXT,
                rating INTEGER,
                correction TEXT
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS rules (
                id TEXT PRIMARY KEY,
                ts TEXT NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                enabled INTEGER NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS sources (
                domain TEXT PRIMARY KEY,
                trust INTEGER NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        con.commit()


def upsert_user(user_id: str, profile: dict | None = None):
    profile = profile or {}
    now = utc_now_iso()
    with db() as con:
        row = con.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,)).fetchone()
        if row:
            con.execute("UPDATE users SET last_seen_at = ?, profile_json = ? WHERE user_id = ?",
                        (now, json.dumps(profile, ensure_ascii=False), user_id))
        else:
            con.execute("INSERT INTO users (user_id, created_at, last_seen_at, profile_json) VALUES (?,?,?,?)",
                        (user_id, now, now, json.dumps(profile, ensure_ascii=False)))
        con.commit()

def add_message(user_id: str, session_id: str, role: str, content: str, meta: dict | None = None):
    meta = meta or {}
    mid = str(uuid.uuid4())
    with db() as con:
        con.execute(
            "INSERT INTO messages (id, user_id, session_id, role, content, created_at, meta_json) VALUES (?,?,?,?,?,?,?)",
            (mid, user_id, session_id, role, content, utc_now_iso(), json.dumps(meta, ensure_ascii=False))
        )
        con.commit()
    return mid

def log_audit(action: str, detail: dict, user_id: str | None = None, session_id: str | None = None):
    with db() as con:
        con.execute(
            "INSERT INTO audit (id, ts, user_id, session_id, action, detail_json) VALUES (?,?,?,?,?,?)",
            (str(uuid.uuid4()), utc_now_iso(), user_id, session_id, action, json.dumps(detail, ensure_ascii=False))
        )
        con.commit()

def get_recent_context(user_id: str, session_id: str, limit: int = 14) -> list[dict]:
    with db() as con:
        rows = con.execute(
            "SELECT role, content FROM messages WHERE user_id = ? AND session_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, session_id, limit)
        ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]

def get_user_summary(user_id: str) -> str:
    with db() as con:
        row = con.execute("SELECT summary FROM summaries WHERE user_id = ?", (user_id,)).fetchone()
    return row["summary"] if row else ""

def set_user_summary(user_id: str, summary: str):
    with db() as con:
        row = con.execute("SELECT user_id FROM summaries WHERE user_id = ?", (user_id,)).fetchone()
        if row:
            con.execute("UPDATE summaries SET updated_at = ?, summary = ? WHERE user_id = ?",
                        (utc_now_iso(), summary, user_id))
        else:
            con.execute("INSERT INTO summaries (user_id, updated_at, summary) VALUES (?,?,?)",
                        (user_id, utc_now_iso(), summary))
        con.commit()

def get_enabled_rules() -> list[dict]:
    with db() as con:
        rows = con.execute("SELECT id, title, body FROM rules WHERE enabled = 1 ORDER BY ts DESC").fetchall()
    return [{"id": r["id"], "title": r["title"], "body": r["body"]} for r in rows]

def domain_from_url(url: str) -> str:
    try:
        import urllib.parse as up
        return up.urlparse(url).netloc.lower()
    except Exception:
        return ""

def get_source_trust(domain: str) -> int:
    if not domain:
        return 50
    with db() as con:
        row = con.execute("SELECT trust FROM sources WHERE domain = ?", (domain,)).fetchone()
    return int(row["trust"]) if row else 50

def set_source_trust(domain: str, trust: int):
    trust = max(0, min(100, int(trust)))
    with db() as con:
        row = con.execute("SELECT domain FROM sources WHERE domain = ?", (domain,)).fetchone()
        if row:
            con.execute("UPDATE sources SET trust = ?, updated_at = ? WHERE domain = ?",
                        (trust, utc_now_iso(), domain))
        else:
            con.execute("INSERT INTO sources (domain, trust, updated_at) VALUES (?,?,?)",
                        (domain, trust, utc_now_iso()))
        con.commit()

def allowlisted(domain: str) -> bool:
    if not K1_SOURCE_ALLOWLIST.strip():
        return True
    allowed = [d.strip().lower() for d in K1_SOURCE_ALLOWLIST.split(",") if d.strip()]
    return any(domain == d or domain.endswith("." + d) for d in allowed)

# --- OpenAI helpers ---

def openai_headers_json():
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not configured")
    return {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"}

def call_openai_chat(user_id: str, user_text: str, context: list[dict]) -> dict:
    user_summary = get_user_summary(user_id)
    rules = get_enabled_rules()
    rules_text = "\n".join([f"- {r['title']}: {r['body']}" for r in rules])
    system_instructions = (
        "You are Kelion, a WebGL hologram assistant.\n"
        "USER SUMMARY (persistent memory, may be empty):\n" + user_summary + "\n"
        "ADMIN RULES (must follow):\n" + rules_text + "\n"
        f"Default language: {DEFAULT_LANGUAGE}.\n"
        "Tone: friendly, conversational.\n"
        "You should answer directly. Do not mention tools.\n"
        "If the user asks to delete/reset memory: refuse politely. Users cannot delete data; only admin/legal process.\n"
        "When the situation is ambiguous or information is uncertain: ask a clarifying question first.\n"
        "If after clarification you believe the request is illegal or unsafe: refuse politely and explain limits.\n"
        "You may use web search for up-to-date information when needed.\n"
        "Return: plain answer text + optionally sources list.\n"
    )

    dialog = []
    for m in context:
        dialog.append({"role": m["role"], "content": m["content"]})
    dialog.append({"role": "user", "content": user_text})

    payload = {
        "model": OPENAI_MODEL,
        "reasoning": {"effort": OPENAI_REASONING_EFFORT},
        "tools": [{"type": "web_search"}],
        "tool_choice": "auto",
        "include": ["web_search_call.action.sources"],
        "input": [{"role": "system", "content": system_instructions}, *dialog],
    }

    r = requests.post(f"{OPENAI_BASE_URL}/responses", headers=openai_headers_json(), json=payload, timeout=60)
    r.raise_for_status()
    data = r.json()

    output_text = ""
    sources = []
    for item in data.get("output", []):
        if item.get("type") == "message":
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    output_text += part.get("text", "")
        if item.get("type") == "web_search_call":
            action = item.get("action") or {}
            for s in (action.get("sources") or []):
                if s.get("url"):
                    sources.append({"url": s.get("url"), "title": s.get("title") or ""})

    if not sources and data.get("sources"):
        for s in data["sources"]:
            if s.get("url"):
                sources.append({"url": s.get("url"), "title": s.get("title") or ""})

    # simple emotion classifier
    t = (output_text or "").lower()
    emotion = "calm"
    if any(w in t for w in ["great", "awesome", "amazing", "love", "congrats"]):
        emotion = "happy"
    if any(w in t for w in ["sorry", "apologize", "i understand", "i'm here for you"]):
        emotion = "empathetic"

    filtered = []
    for s in sources:
        d = domain_from_url(s.get("url",""))
        if not allowlisted(d):
            continue
        s["domain"] = d
        s["trust"] = get_source_trust(d)
        filtered.append(s)
    filtered.sort(key=lambda x: x.get("trust", 50), reverse=True)
    return {"text": output_text.strip(), "sources": filtered[:8], "emotion": emotion}


def call_openai_tts(text: str) -> str | None:
    if not OPENAI_API_KEY:
        return None
    os.makedirs(AUDIO_DIR, exist_ok=True)
    audio_id = str(uuid.uuid4())
    out_path = os.path.join(AUDIO_DIR, f"{audio_id}.mp3")

    payload = {
        "model": OPENAI_TTS_MODEL,
        "voice": OPENAI_TTS_VOICE,
        "input": text,
        "instructions": "Speak in a friendly, conversational tone. Male voice."
    }
    r = requests.post(f"{OPENAI_BASE_URL}/audio/speech", headers=openai_headers_json(), json=payload, timeout=60)
    r.raise_for_status()
    with open(out_path, "wb") as f:
        f.write(r.content)
    return f"/audio/{audio_id}.mp3"

def maybe_update_summary(user_id: str, session_id: str):
    # Update summary every ~30 user messages
    with db() as con:
        row = con.execute("SELECT COUNT(*) c FROM messages WHERE user_id = ? AND role = 'user'", (user_id,)).fetchone()
    c = int(row["c"])
    if c % 30 != 0:
        return
    recent = get_recent_context(user_id, session_id, limit=40)
    current = get_user_summary(user_id)
    prompt = (
        "Update the USER SUMMARY with stable facts, preferences and goals. "
        "Keep it short (max 12 bullet points). "
        "If nothing new, keep it unchanged.\n\n"
        f"CURRENT SUMMARY:\n{current}\n\nRECENT DIALOG:\n" +
        "\n".join([f"{m['role'].upper()}: {m['content']}" for m in recent])
    )
    try:
        payload = {
            "model": OPENAI_MODEL,
            "reasoning": {"effort": "low"},
            "input": [
                {"role": "system", "content": "You are a summarizer for long-term memory."},
                {"role": "user", "content": prompt},
            ],
        }
        r = requests.post(f"{OPENAI_BASE_URL}/responses", headers=openai_headers_json(), json=payload, timeout=60)
        r.raise_for_status()
        data = r.json()
        txt = ""
        for item in data.get("output", []):
            if item.get("type") == "message":
                for part in item.get("content", []):
                    if part.get("type") == "output_text":
                        txt += part.get("text", "")
        txt = (txt or "").strip()
        if txt:
            set_user_summary(user_id, txt)
            log_audit("summary_updated", {"len": len(txt)}, user_id=user_id, session_id=session_id)
    except Exception as e:
        log_audit("summary_error", {"error": str(e)}, user_id=user_id, session_id=session_id)

def call_openai_stt_words(file_bytes: bytes, filename: str = "audio.mp3") -> dict:
    """Transcribe audio and return word-level timestamps (verbose_json + timestamp_granularities[]=word)."""
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not configured")
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    files = {"file": (filename, file_bytes)}
    data = [
        ("model", OPENAI_STT_MODEL),
        ("language", "en"),
        ("response_format", "verbose_json"),
        ("timestamp_granularities[]", "word"),
    ]
    r = requests.post(f"{OPENAI_BASE_URL}/audio/transcriptions", headers=headers, files=files, data=data, timeout=60)
    r.raise_for_status()
    return r.json()

def make_viseme_timeline(words: list[dict]) -> list[dict]:
    """Convert word timestamps -> a simple viseme timeline (heuristic)."""
    def viseme_for_word(w: str) -> str:
        w = (w or "").lower()
        if not w:
            return "REST"
        if w.startswith("th"):
            return "TH"
        if w.startswith(("ch", "sh", "j", "zh")):
            return "CH"
        if w.startswith(("f", "v")):
            return "FV"
        if w.startswith(("m", "b", "p")):
            return "MBP"
        if w.startswith(("k", "g", "q", "c")):
            return "KG"
        if w.startswith(("s", "z", "x")):
            return "S"
        if w.startswith("r"):
            return "R"
        if w.startswith("l"):
            return "L"
        if w.startswith("w"):
            return "WQ"
        m = re.search(r"[aeiouy]+", w)
        if not m:
            return "REST"
        v = m.group(0)
        if v in ("oo", "u", "ou", "ow"):
            return "OO"
        if v in ("ee", "i", "ie", "ei", "y"):
            return "EE"
        return "AA"

    tl = []
    for it in words or []:
        try:
            t0 = float(it.get("start", 0.0))
            t1 = float(it.get("end", t0 + 0.12))
            word = it.get("word") or ""
            tl.append({"t0": t0, "t1": t1, "viseme": viseme_for_word(word)})
        except Exception:
            continue
    return tl

def call_openai_stt(file_bytes: bytes, filename: str = "speech.webm") -> str:

    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not configured")
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    files = {"file": (filename, file_bytes)}
    data = {"model": OPENAI_STT_MODEL, "language": "en"}
    r = requests.post(f"{OPENAI_BASE_URL}/audio/transcriptions", headers=headers, files=files, data=data, timeout=60)
    r.raise_for_status()
    j = r.json()
    return (j.get("text") or "").strip()

# --- Routes (Kelion-like) ---
@app.get("/health")
def health():
    return jsonify({"status": "ok", "ts": int(time.time())}), 200

@app.after_request
def add_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # CORS is handled by Flask-CORS usually, but explicit here if needed
    response.headers["Access-Control-Allow-Origin"] = "*" 
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Token, X-Admin-Token"
    return response

# Rate Limit generic (in-memory simple)
REQUEST_COUNTS = {}
@app.before_request
def limit_check():
    ip = request.remote_addr
    now = time.time()
    # clean old
    to_del = [k for k,v in REQUEST_COUNTS.items() if now - v['start'] > 60]
    for k in to_del: del REQUEST_COUNTS[k]
    
    if ip not in REQUEST_COUNTS:
        REQUEST_COUNTS[ip] = {'count': 1, 'start': now}
    else:
        REQUEST_COUNTS[ip]['count'] += 1
        if REQUEST_COUNTS[ip]['count'] > 300: # 300 req/min
            return jsonify({"error": "Too many requests"}), 429

@app.get("/")
def index():
    return send_from_directory("static", "index.html")

@app.get("/audio/<path:filename>")
def audio_file(filename: str):
    return send_from_directory(os.path.join("static", "audio"), filename)

@app.post("/api/stt")
def api_stt():
    if not _auth_ok(request):
        return jsonify({"error": "Unauthorized"}), 401
    if "audio" not in request.files:
        return jsonify({"error": "Missing audio file"}), 400
    f = request.files["audio"]
    b = f.read()
    if not b:
        return jsonify({"error": "Empty audio file"}), 400
    try:
        if request.args.get('verbose') == '1':
            j = call_openai_stt_words(b, filename=f.filename or 'speech.webm')
            return jsonify(j), 200
        text = call_openai_stt(b, filename=f.filename or "speech.webm")
        return jsonify({"text": text}), 200
    except Exception as e:
        log_audit("stt_error", {"error": str(e)})
        return jsonify({"error": "STT failed"}), 500

@app.post("/api/login")
def api_login():
    # Minimal login per spec; extend as needed.
    payload = request.get_json(silent=True) or {}
    user = (payload.get("user") or "user").strip()
    user_id = payload.get("userId") or user or "user"
    upsert_user(user_id, profile={"language": DEFAULT_LANGUAGE, "persona": PERSONA_STYLE, "login_user": user})
    log_audit("login", {"user": user}, user_id=user_id, session_id="web")
    return jsonify({"ok": True, "userId": user_id, "mode": "OpenAI", "status": "active", "version": "k1.1.0"}), 200

@app.post("/api/chat")
def api_chat():
    if not _auth_ok(request):
        return jsonify({"error": "Unauthorized"}), 401

    payload = request.get_json(silent=True) or {}
    user_id = payload.get("userId") or "anon"
    session_id = payload.get("sessionId") or "web"
    text = (payload.get("text") or "").strip()
    if not text:
        return jsonify({"error": "Missing text"}), 400

    # --- Subscription Logic ---
    SUBSCRIPTION_LIMITS = {
        "Starter": 50,    # messages per day
        "Pro": 500,
        "Elite": 999999
    }

    def get_user_tier(user_id: str) -> str:
        with db() as con:
            row = con.execute("SELECT profile_json FROM users WHERE user_id = ?", (user_id,)).fetchone()
        if not row:
            return "Starter"
        try:
            profile = json.loads(row["profile_json"])
            return profile.get("tier", "Starter")
        except:
            return "Starter"

    def check_rate_limit(user_id: str) -> bool:
        tier = get_user_tier(user_id)
        limit = SUBSCRIPTION_LIMITS.get(tier, 50)
        today = utc_now_iso().split("T")[0]
        
        with db() as con:
            row = con.execute(
                "SELECT COUNT(*) c FROM messages WHERE user_id = ? AND role = 'user' AND created_at LIKE ?", 
                (user_id, f"{today}%")
            ).fetchone()
        
        count = row["c"] if row else 0
        return count < limit

    upsert_user(user_id, profile={"language": DEFAULT_LANGUAGE, "persona": PERSONA_STYLE})
    
    if not check_rate_limit(user_id):
         return jsonify({"error": "Daily message limit reached for your plan. Upgrade to chat more."}), 403

    log_audit("user_input", {"text": text}, user_id=user_id, session_id=session_id)
    add_message(user_id, session_id, "user", text, meta={"via": "text"})

    ctx = get_recent_context(user_id, session_id, limit=14)
    try:
        ai = call_openai_chat(user_id, text, context=ctx)
    except Exception as e:
        log_audit("ai_error", {"error": str(e)}, user_id=user_id, session_id=session_id)
        ai = {"text": "I’m having trouble reaching my AI service right now. Please try again in a moment.", "sources": [], "emotion": "empathetic"}

    add_message(user_id, session_id, "assistant", ai["text"], meta={"emotion": ai.get("emotion"), "sources": ai.get("sources")})
    maybe_update_summary(user_id, session_id)
    log_audit("assistant_output", {"text": ai["text"], "sources": ai.get("sources", [])}, user_id=user_id, session_id=session_id)

    audio_url = None
    try:
        audio_url = call_openai_tts(ai["text"])
        if audio_url:
            log_audit("tts_generated", {"audio_url": audio_url}, user_id=user_id, session_id=session_id)
    except Exception as e:
        log_audit("tts_error", {"error": str(e)}, user_id=user_id, session_id=session_id)

    lipsync = None
    if audio_url:
        try:
            audio_file_path = os.path.join(AUDIO_DIR, audio_url.split("/")[-1])
            with open(audio_file_path, "rb") as af:
                tjson = call_openai_stt_words(af.read(), filename=audio_url.split("/")[-1])
            words = tjson.get("words") or []
            lipsync = {"words": words, "visemes": make_viseme_timeline(words)}
            log_audit("lipsync_generated", {"words": len(words)}, user_id=user_id, session_id=session_id)
        except Exception as e:
            log_audit("lipsync_error", {"error": str(e)}, user_id=user_id, session_id=session_id)

    # Animation hint for UI
    animation = "idle"
    if audio_url:
        animation = "speak"
    if ai.get("emotion") == "happy":
        animation = "happy"
    if ai.get("emotion") == "empathetic":
        animation = "empathetic"

    return jsonify({
        "text": ai["text"],
        "emotion": ai.get("emotion", "calm"),
        "audioUrl": audio_url,
        "sources": ai.get("sources", []),
        "animation": animation,
        "lipsync": lipsync
    }), 200

# Alias endpoints (compatibility)
@app.post("/external/input")
def external_input():
    return api_chat()

@app.post("/api/contact_submit")
def api_contact():
    payload = request.get_json(silent=True) or {}
    name = (payload.get("name") or "").strip()
    email = (payload.get("email") or "").strip()
    message = (payload.get("message") or "").strip()
    lid = str(uuid.uuid4())
    with db() as con:
        con.execute("INSERT INTO leads (id, ts, name, email, message) VALUES (?,?,?,?,?)",
                    (lid, utc_now_iso(), name, email, message))
        con.commit()
    log_audit("contact_submit", {"id": lid, "email": email})
    return jsonify({"ok": True, "id": lid}), 200

@app.post("/api/narrate")
def api_narrate():
    """Generate cinematic narrator voice for intro/presentation."""
    payload = request.get_json(silent=True) or {}
    text = (payload.get("text") or "").strip()
    if not text:
        return jsonify({"error": "Missing text"}), 400
    
    if not OPENAI_API_KEY:
        return jsonify({"error": "TTS not configured"}), 500
    
    try:
        os.makedirs(AUDIO_DIR, exist_ok=True)
        audio_id = str(uuid.uuid4())
        out_path = os.path.join(AUDIO_DIR, f"{audio_id}.mp3")
        
        # Use "onyx" for deep male narrator voice
        narrator_voice = os.getenv("OPENAI_NARRATOR_VOICE", "onyx")
        
        payload_tts = {
            "model": OPENAI_TTS_MODEL,
            "voice": narrator_voice,
            "input": text,
            "instructions": "Speak in a deep, cinematic, dramatic narrator voice. Slow pace, building atmosphere. Like an epic movie trailer."
        }
        logger.info(f"Narrate request: voice={narrator_voice}, text_len={len(text)}")
        r = requests.post(f"{OPENAI_BASE_URL}/audio/speech", headers=openai_headers_json(), json=payload_tts, timeout=90)
        r.raise_for_status()
        with open(out_path, "wb") as f:
            f.write(r.content)
        
        audio_url = f"/audio/{audio_id}.mp3"
        log_audit("narrate_generated", {"audio_url": audio_url, "text_len": len(text)})
        return jsonify({"audioUrl": audio_url}), 200
    except Exception as e:
        logger.error(f"Narrate error: {e}")
        log_audit("narrate_error", {"error": str(e)})
        return jsonify({"error": f"Narration failed: {str(e)}"}), 500


@app.get("/api/pricing")
def api_pricing():
    return jsonify({
        "currency": "USD",
        "tiers": [
            {"name": "Starter", "price": 19, "features": ["Web hologram", "AI chat", "Basic support"]},
            {"name": "Pro", "price": 59, "features": ["Voice (TTS/STT)", "Persistent memory", "Admin audit"]},
            {"name": "Enterprise", "price": 199, "features": ["Custom workflows", "Legal-grade audit", "SLA"]},
        ]
    }), 200

@app.get("/api/plans")
def api_plans():
    return api_pricing()

@app.post("/api/subscribe")
def api_subscribe():
    payload = request.get_json(silent=True) or {}
    tier = payload.get("tier") or "Starter"
    email = payload.get("email") or ""
    # In a real app, verify payment here.
    # For now, we trust the frontend request or default to free.
    
    # We need the user_id context, usually from auth token or payload
    # Assuming user_id is passed or inferred (here we take from payload for simplicity demo)
    user_id = payload.get("userId") or "user" 
    
    # Update user profile
    upsert_user(user_id, profile={"tier": tier, "email": email, "updated_at": utc_now_iso()})
    
    log_audit("subscribe", {"tier": tier, "email": email}, user_id=user_id)
    return jsonify({"ok": True, "tier": tier}), 200

@app.get("/api/dashboard")
def api_dashboard():
    # Minimal dashboard data (admin can expand)
    with db() as con:
        u = con.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        m = con.execute("SELECT COUNT(*) c FROM messages").fetchone()["c"]
        l = con.execute("SELECT COUNT(*) c FROM leads").fetchone()["c"]
    return jsonify({"users": u, "messages": m, "leads": l, "version": "k1.1.0"}), 200

# Admin endpoints (audit + messages)
@app.get("/admin/audit")
def admin_audit():
    if not _admin_ok(request):
        return jsonify({"error": "Unauthorized"}), 401
    limit = int(request.args.get("limit", "100"))
    with db() as con:
        rows = con.execute("SELECT ts, user_id, session_id, action, detail_json FROM audit ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
    items = []
    for r in rows:
        items.append({
            "ts": r["ts"],
            "user_id": r["user_id"],
            "session_id": r["session_id"],
            "action": r["action"],
            "detail": json.loads(r["detail_json"])
        })
    return jsonify({"items": items}), 200

@app.get("/admin/messages")
def admin_messages():
    if not _admin_ok(request):
        return jsonify({"error": "Unauthorized"}), 401
    user_id = request.args.get("user_id", "anon")
    limit = int(request.args.get("limit", "100"))
    with db() as con:
        rows = con.execute(
            "SELECT created_at, session_id, role, content, meta_json FROM messages WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit)
        ).fetchall()
    items = []
    for r in rows:
        items.append({
            "created_at": r["created_at"],
            "session_id": r["session_id"],
            "role": r["role"],
            "content": r["content"],
            "meta": json.loads(r["meta_json"])
        })
    return jsonify({"user_id": user_id, "items": items}), 200

@app.post("/api/feedback")
def api_feedback():
    if not _auth_ok(request):
        return jsonify({"error": "Unauthorized"}), 401
    payload = request.get_json(silent=True) or {}
    user_id = payload.get("userId") or "anon"
    session_id = payload.get("sessionId") or "web"
    message_id = payload.get("messageId")
    rating = payload.get("rating")
    correction = (payload.get("correction") or "").strip()
    fid = str(uuid.uuid4())
    with db() as con:
        con.execute(
            "INSERT INTO feedback (id, ts, user_id, session_id, message_id, rating, correction) VALUES (?,?,?,?,?,?,?)",
            (fid, utc_now_iso(), user_id, session_id, message_id, rating, correction)
        )
        con.commit()
    log_audit("feedback", {"id": fid, "rating": rating}, user_id=user_id, session_id=session_id)
    return jsonify({"ok": True, "id": fid}), 200

@app.post("/admin/rules")
def admin_rules_upsert():
    if not _admin_ok(request):
        return jsonify({"error": "Unauthorized"}), 401
    payload = request.get_json(silent=True) or {}
    title = (payload.get("title") or "").strip()
    body = (payload.get("body") or "").strip()
    enabled = 1 if payload.get("enabled", True) else 0
    if not title or not body:
        return jsonify({"error": "Missing title/body"}), 400
    rid = str(uuid.uuid4())
    with db() as con:
        con.execute("INSERT INTO rules (id, ts, title, body, enabled) VALUES (?,?,?,?,?)",
                    (rid, utc_now_iso(), title, body, enabled))
        con.commit()
    return jsonify({"ok": True, "id": rid}), 200

@app.post("/admin/sources")
def admin_sources_set():
    if not _admin_ok(request):
        return jsonify({"error": "Unauthorized"}), 401
    payload = request.get_json(silent=True) or {}
    domain = (payload.get("domain") or "").strip().lower()
    trust = payload.get("trust", 50)
    if not domain:
        return jsonify({"error": "Missing domain"}), 400
    set_source_trust(domain, int(trust))
    return jsonify({"ok": True, "domain": domain, "trust": get_source_trust(domain)}), 200

# ============================================
# RAILWAY DEPLOY ENDPOINTS
# ============================================

@app.get("/api/railway/config")
def railway_config_status():
    try:
        manager = get_deploy_manager()
        return jsonify({"success": True, "config": manager.get_config_status()}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.get("/api/railway/info")
def railway_service_info():
    try:
        manager = get_deploy_manager()
        return jsonify({"success": True, "service": manager.get_service_info()}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.post("/api/railway/deploy")
def railway_deploy():
    if DEPLOY_API_KEY:
        auth = request.headers.get("Authorization", "")
        if auth != f"Bearer {DEPLOY_API_KEY}":
            return jsonify({"error": "Unauthorized"}), 401
    try:
        manager = get_deploy_manager()
        result = manager.deploy()
        code = 200 if result.get("success") else 500
        return jsonify(result), code
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.get("/api/railway/health")
def railway_health():
    try:
        manager = get_deploy_manager()
        cfg = manager.get_config_status()
        all_set = all([cfg["railway_token_set"], cfg["service_id_set"], cfg["project_id_set"]])
        return jsonify({
            "success": True,
            "healthy": all_set,
            "message": "Railway deploy system is ready" if all_set else "Missing configuration",
            "config": cfg
        }), 200
    except Exception as e:
        return jsonify({"success": False, "healthy": False, "error": str(e)}), 500

# ============================================
# FIN RAILWAY DEPLOY ENDPOINTS
# ============================================

init_db()

if __name__ == "__main__":

    app.run(host="0.0.0.0", port=PORT)
