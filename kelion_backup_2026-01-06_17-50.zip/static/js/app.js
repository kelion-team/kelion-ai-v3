import { HologramUnit } from "./holograma_k.js";

/* Presence UI status bar + tabs */
function initStatusBar() {
  const vEl = document.getElementById("k1Version");
  const cEl = document.getElementById("k1Clock");
  const dEl = document.getElementById("k1Date");
  if (vEl) vEl.textContent = window.K1_VERSION || "v1.0.0";
  function tick() {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    if (cEl) cEl.textContent = `${hh}:${mm}`;
    if (dEl) dEl.textContent = now.toISOString().slice(0, 10);
  }
  tick();
  setInterval(tick, 30_000);
}

function initTabs() {
  const readBtn = document.getElementById("tabRead");
  const writeBtn = document.getElementById("tabWrite");
  const pRead = document.getElementById("panelRead");
  const pWrite = document.getElementById("panelWrite");
  const setTab = (which) => {
    if (!readBtn || !writeBtn || !pRead || !pWrite) return;
    if (which === "read") {
      readBtn.classList.add("active"); writeBtn.classList.remove("active");
      pRead.classList.add("active"); pWrite.classList.remove("active");
    } else {
      writeBtn.classList.add("active"); readBtn.classList.remove("active");
      pWrite.classList.add("active"); pRead.classList.remove("active");
      const ti = document.getElementById("textInput");
      if (ti) ti.focus();
    }
  };
  if (readBtn) readBtn.onclick = () => setTab("read");
  if (writeBtn) writeBtn.onclick = () => setTab("write");
  setTab("write");
}

// DOM Elements
const chatLog = document.getElementById("chatLog");
const subtitleEl = document.getElementById("k1Subtitle");

function append(role, text) {
  // Save last bot text for syncing
  if (role === 'bot') {
    window.lastBotText = text;
  }

  // Add to History Log (always)
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = text;
  if (chatLog) {
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  // If BOT, trigger Typewriter Subtitle
  if (role === 'bot') {
    runTypewriter(text);
  }
}

let typewriterTimeout;
function runTypewriter(text, audioDuration = 0) {
  if (!subtitleEl) return;

  // Clear previous
  subtitleEl.innerHTML = '';
  clearTimeout(typewriterTimeout);

  const span = document.createElement("span");
  span.className = "k1-subtitle-text";
  subtitleEl.appendChild(span);

  // Calculate speed
  let charDelay = 30; // default ms per char
  if (audioDuration > 0 && text.length > 0) {
    charDelay = (audioDuration * 1000) / text.length;
  }

  let i = 0;
  function type() {
    if (i < text.length) {
      span.textContent += text.charAt(i);
      i++;
      typewriterTimeout = setTimeout(type, charDelay);
    } else {
      // Done typing. Wait 1s then slide out.
      setTimeout(() => {
        span.classList.add("k1-slide-out");
      }, 1000);
    }
  }
  type();
}

const $ = (id) => document.getElementById(id);

// Elements matching index.html
const welcome = $("welcome");
const enterBtn = $("enterBtn");
const clockEl = $("k1Clock");
const modeEl = $("k1Version");
const cloudEl = $("k1Net");
const chatInput = $("textInput");
const sendBtn = $("btnSend");
const micBtn = $("btnMic");
const sourcesBox = $("chatLog");

const pricingBox = $("pricingBox");
const contactBtn = $("contactBtn");
const contactOk = $("contactOk");

// Create audio element for TTS
let audioEl = $("tts");
if (!audioEl) {
  audioEl = document.createElement("audio");
  audioEl.id = "tts";
  audioEl.style.display = "none";
  document.body.appendChild(audioEl);
}

// Unlock audio context on user gesture (required for autoplay in browsers)
let audioContextUnlocked = false;
function unlockAudioContext() {
  if (audioContextUnlocked) return;

  // Create and resume AudioContext
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (AudioContext) {
    const ctx = new AudioContext();
    ctx.resume().then(() => {
      console.log("AudioContext unlocked");
      audioContextUnlocked = true;
    });
  }

  // Also play a silent audio to unlock
  audioEl.muted = true;
  audioEl.play().then(() => {
    audioEl.pause();
    audioEl.muted = false;
    audioEl.currentTime = 0;
    console.log("Audio element unlocked");
  }).catch(() => { });
}

const USER_ID = localStorage.getItem("k1_user_id") || (() => {
  const id = crypto.randomUUID();
  localStorage.setItem("k1_user_id", id);
  return id;
})();

const SESSION_ID = localStorage.getItem("k1_session_id") || (() => {
  const id = crypto.randomUUID();
  localStorage.setItem("k1_session_id", id);
  return id;
})();

let recording = false;
let mediaRecorder = null;
let chunks = [];

function setSources(sources = []) {
  if (!sources || !sources.length || !sourcesBox) {
    if (sourcesBox) sourcesBox.innerHTML = "";
    return;
  }
  const items = sources.slice(0, 5).map((s) => {
    const a = document.createElement("a");
    a.href = s.url;
    a.target = "_blank";
    a.rel = "noreferrer";
    a.textContent = s.title || s.url;
    const trust = (s.trust !== undefined) ? ` (trust ${s.trust}/100)` : '';
    const span = document.createElement('span');
    span.className = 'small';
    span.style.marginLeft = '6px';
    span.textContent = trust;
    const row = document.createElement("div");
    row.append("• ", a, span);
    return row.outerHTML;
  }).join("");
  sourcesBox.innerHTML = `<div class="small" style="font-weight:600;margin-bottom:4px;">Sources</div>${items}`;
}

async function login() {
  // Get authenticated user from localStorage
  const authenticatedUser = localStorage.getItem('k1_user') || 'user';
  const authenticatedUserId = localStorage.getItem('k1_user_id') || USER_ID;

  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: authenticatedUserId, user: authenticatedUser })
    });
    const data = await res.json();
    if (modeEl) modeEl.textContent = `v1.0.0 • ${data.mode || "OpenAI"}`;
    if (cloudEl) cloudEl.textContent = data.status || "Online";
  } catch (e) {
    console.error("Login error:", e);
  }

  // Auth / Menu Logic
  const authBtn = document.getElementById("k1AuthBtn");
  const dash = document.getElementById("k1Dashboard");
  const closeDash = document.getElementById("k1CloseDash");

  if (closeDash) closeDash.onclick = () => { dash.style.display = "none"; };

  if (authBtn) {
    const isAuthenticated = localStorage.getItem('k1_authenticated') === 'true';
    const username = localStorage.getItem('k1_user') || 'User';

    // Show username and menu/logout options
    if (isAuthenticated) {
      authBtn.textContent = username.toUpperCase();
      authBtn.title = 'Click to open menu or logout';
    } else {
      authBtn.textContent = 'LOGIN';
    }

    authBtn.onclick = async () => {
      if (isAuthenticated) {
        // Show menu with logout option
        if (dash) {
          dash.style.display = "flex";
        }
      } else {
        // Clear any existing auth and reload to show login page
        localStorage.removeItem('k1_authenticated');
        localStorage.removeItem('k1_user');
        localStorage.removeItem('k1_user_id');
        location.reload();
      }
    };
  }

  // Add logout button to dashboard
  addLogoutButton();

  const k1ContactBtn = document.getElementById("k1ContactBtn");
  if (k1ContactBtn) {
    k1ContactBtn.onclick = () => {
      window.location.href = "mailto:contact@kelionai.app?subject=K1%20Inquiry";
    };
  }
}

function addLogoutButton() {
  const dashGrid = document.querySelector('.k1-dash-grid');
  if (!dashGrid) return;

  // Check if logout button already exists
  if (document.getElementById('k1LogoutCard')) return;

  const logoutCard = document.createElement('div');
  logoutCard.id = 'k1LogoutCard';
  logoutCard.className = 'k1-card';
  logoutCard.innerHTML = `
    <h3>LOGOUT</h3>
    <p>Exit session</p>
    <button id="k1LogoutBtn">SIGN OUT</button>
  `;
  dashGrid.appendChild(logoutCard);

  const logoutBtn = document.getElementById('k1LogoutBtn');
  if (logoutBtn) {
    logoutBtn.onclick = () => {
      // Clear all auth data
      localStorage.removeItem('k1_authenticated');
      localStorage.removeItem('k1_user');
      localStorage.removeItem('k1_user_id');
      localStorage.removeItem('k1_api_token');
      // Reload to show login page
      location.reload();
    };
  }
}

function tickClock() {
  if (!clockEl) return;
  const d = new Date();
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  clockEl.textContent = `${hh}:${mm}:${ss}`;
}
setInterval(tickClock, 500);
tickClock();

// Tabs
document.querySelectorAll(".tab").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tabbody").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    const tabEl = $("tab-" + tab);
    if (tabEl) tabEl.classList.add("active");
  });
});

// WebGL hologram - Lazy initialization
let holo = null;
let holoInitialized = false;

function initHologram() {
  if (holoInitialized) return;

  const hologramMount = document.getElementById('hologramMount');
  if (!hologramMount) {
    console.error('Hologram mount not found!');
    return;
  }

  // Ensure container is visible and has size
  hologramMount.style.opacity = '1';
  hologramMount.style.visibility = 'visible';

  // Force layout recalculation
  hologramMount.offsetHeight;

  console.log('Initializing hologram...', hologramMount.clientWidth, hologramMount.clientHeight);

  holo = new HologramUnit("hologramMount");
  holo.init();
  holo.attachAudioElement(audioEl);

  audioEl.addEventListener("play", () => holo.setState("speak"));
  audioEl.addEventListener("ended", () => holo.setState("idle"));

  // Force resize after a short delay to ensure proper dimensions
  setTimeout(() => {
    if (holo) holo.resize();
  }, 100);

  setTimeout(() => {
    if (holo) holo.resize();
  }, 500);

  holoInitialized = true;
  console.log('Hologram initialized!');
}

async function sendFeedback(rating, correction = "") {
  try {
    await fetch("/api/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: USER_ID, sessionId: SESSION_ID, rating, correction })
    });
  } catch (e) { }
}

async function sendText(text) {
  const t = (text || "").trim();
  if (!t) return;
  append("user", t);
  if (chatInput) chatInput.value = "";
  setSources([]);
  holo.setState("processing");

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-Token": localStorage.getItem("k1_api_token") || ""
      },
      body: JSON.stringify({
        text: t,
        userId: USER_ID,
        sessionId: SESSION_ID
      })
    });
    const data = await res.json();
    if (!res.ok) {
      append("bot", data.error || "Request failed.");
      holo.setState("idle");
      return;
    }
    append("bot", data.text || "");

    // Feedback buttons
    const fbRow = document.createElement("div");
    fbRow.className = "small";
    fbRow.style.margin = "6px 0 0";
    fbRow.innerHTML = `<button class="btn" style="padding:6px 10px" id="fbUp">👍</button> <button class="btn" style="padding:6px 10px" id="fbDown">👎</button>`;
    if (chatLog) {
      chatLog.appendChild(fbRow);
      chatLog.scrollTop = chatLog.scrollHeight;
    }
    const upBtn = fbRow.querySelector("#fbUp");
    const downBtn = fbRow.querySelector("#fbDown");
    if (upBtn) upBtn.onclick = () => sendFeedback(5);
    if (downBtn) downBtn.onclick = () => sendFeedback(1);

    setSources(data.sources || []);

    // Set hologram state using the full backend response structure
    holo.setStateFromBackend({
      animation: data.animation || 'idle',
      emotion: data.emotion || 'calm',
      lipsync: data.lipsync
    });

    if (data.audioUrl) {
      console.log("Loading audio from:", data.audioUrl);
      audioEl.src = data.audioUrl;
      audioEl.volume = 1.0;

      audioEl.onloadedmetadata = () => {
        console.log("Audio loaded, duration:", audioEl.duration);
        if (window.lastBotText) {
          runTypewriter(window.lastBotText, audioEl.duration);
        }
      };

      audioEl.onerror = (e) => {
        console.error("Audio load error:", e, audioEl.error);
      };

      try {
        await audioEl.play();
        console.log("Audio playing successfully");
      } catch (e) {
        console.warn("Audio autoplay blocked:", e.message);
        // Store pending audio for manual trigger
        window.pendingAudio = audioEl;
        // Show a hint to the user
        const hint = document.createElement("div");
        hint.className = "audio-hint";
        hint.innerHTML = "🔊 Click anywhere to enable audio";
        hint.style.cssText = "position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:rgba(0,255,255,0.2);color:#0ff;padding:10px 20px;border-radius:20px;cursor:pointer;z-index:9999;font-size:14px;border:1px solid #0ff;";
        hint.onclick = async () => {
          if (window.pendingAudio) {
            try {
              await window.pendingAudio.play();
              console.log("Audio playing after user gesture");
            } catch (err) {
              console.error("Still cannot play audio:", err);
            }
          }
          hint.remove();
        };
        document.body.appendChild(hint);
        // Also allow clicking anywhere
        document.addEventListener("click", async function unlockAudio() {
          if (window.pendingAudio) {
            try {
              await window.pendingAudio.play();
            } catch (err) { }
            window.pendingAudio = null;
          }
          document.querySelector(".audio-hint")?.remove();
          document.removeEventListener("click", unlockAudio);
        }, { once: true });
      }
    }
  } catch (e) {
    console.error("Chat API error:", e);
    append("bot", "An error occurred while processing your request.");
    holo.setState("idle");
  }
}

// Voice Recording
async function startRecording() {
  if (recording) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    chunks = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    mediaRecorder.onstop = async () => {
      const blob = new Blob(chunks, { type: "audio/webm" });
      const formData = new FormData();
      formData.append("audio", blob, "speech.webm");

      try {
        const res = await fetch("/api/stt", {
          method: "POST",
          headers: { "X-API-Token": localStorage.getItem("k1_api_token") || "" },
          body: formData
        });
        const data = await res.json();
        if (data.text) {
          sendText(data.text);
        }
      } catch (e) {
        console.error("STT error:", e);
        append("bot", "Could not transcribe your speech.");
      }

      stream.getTracks().forEach(t => t.stop());
    };

    mediaRecorder.start();
    recording = true;
    if (micBtn) micBtn.textContent = "⏹️";
  } catch (e) {
    console.error("Microphone error:", e);
    append("bot", "Microphone permission is required for voice input.");
  }
}

function stopRecording() {
  if (!mediaRecorder || !recording) return;
  mediaRecorder.stop();
  recording = false;
  if (micBtn) micBtn.textContent = "🎙️";
}

// Pricing
async function loadPricing() {
  if (!pricingBox) return;
  try {
    const res = await fetch("/api/pricing");
    const data = await res.json();
    pricingBox.innerHTML = (data.tiers || []).map(t => `
      <div class="box" style="border:1px solid var(--border);border-radius:14px;padding:10px;background:rgba(0,0,0,.25)">
        <div style="font-family:Orbitron;color:var(--cyan)">${t.name} – $${t.price}/${data.currency}</div>
        <div class="small">${(t.features || []).map(x => `• ${x}`).join("<br/>")}</div>
      </div>
    `).join("");
  } catch (e) {
    console.error("Pricing error:", e);
  }
}

// ======================================
// VIEWPORT FIT CHECKER - Ensures single page, no scroll
// ======================================
function initViewportFitChecker() {
  const checkFit = () => {
    const vh = window.innerHeight;
    const vw = window.innerWidth;

    // Set CSS variables for dynamic sizing
    document.documentElement.style.setProperty('--vh', `${vh * 0.01}px`);
    document.documentElement.style.setProperty('--vw', `${vw * 0.01}px`);

    // Get main container
    const mainContainer = document.querySelector('.k1-main-unified');
    if (mainContainer) {
      mainContainer.style.height = `${vh}px`;
      mainContainer.style.maxHeight = `${vh}px`;
    }

    // Adjust intro content if exists
    const introContent = document.querySelector('.k1-intro-content');
    if (introContent) {
      const maxContentHeight = vh * 0.9; // 90% of viewport
      const currentHeight = introContent.scrollHeight;

      if (currentHeight > maxContentHeight) {
        // Scale down content to fit
        const scale = Math.max(0.6, maxContentHeight / currentHeight);
        introContent.style.transform = `scale(${scale})`;
      } else {
        introContent.style.transform = 'scale(1)';
      }
    }

    // Prevent any scrolling
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
  };

  // Run on init
  checkFit();

  // Run on resize with debounce
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(checkFit, 100);
  });

  // Run periodically to catch any layout changes
  setInterval(checkFit, 2000);

  // Also check on orientation change for mobile
  window.addEventListener('orientationchange', () => {
    setTimeout(checkFit, 300);
  });
}

// ======================================
// INTRO PAGE - Cinematic Experience
// ======================================

// Narrator audio element
let narratorAudio = null;

async function playIntroNarration() {
  // Collect the story text from the intro
  const storyLines = document.querySelectorAll('.k1-story-line');
  if (!storyLines.length) return;

  // Build the narrator text
  const narratorText = Array.from(storyLines)
    .map(line => line.textContent.trim())
    .join(' ');

  if (!narratorText) return;

  try {
    console.log('Requesting narrator voice...');
    const res = await fetch('/api/narrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: narratorText })
    });

    if (!res.ok) {
      console.warn('Narration API failed:', res.status);
      return;
    }

    const data = await res.json();
    if (data.audioUrl) {
      console.log('Playing narrator audio:', data.audioUrl);
      narratorAudio = new Audio(data.audioUrl);
      narratorAudio.volume = 0.85;

      // Play with slight delay for dramatic effect
      setTimeout(async () => {
        try {
          await narratorAudio.play();
          console.log('Narrator playing!');
        } catch (e) {
          console.warn('Narrator autoplay blocked - will play on click');
          // Will play when user clicks Enter button
          window.pendingNarrator = narratorAudio;
        }
      }, 800);
    }
  } catch (e) {
    console.error('Narrator request failed:', e);
  }
}

function initIntroPage() {
  const introLayer = document.getElementById('k1IntroLayer');
  const enterBtn = document.getElementById('k1EnterBtn');
  const loginLayer = document.getElementById('k1LoginLayer');

  if (!introLayer) {
    // No intro layer, check if logged in
    if (isUserLoggedIn()) {
      initHologramAndApp();
    } else {
      showLoginPage();
    }
    return;
  }

  // Create floating particles
  const particlesContainer = document.getElementById('introParticles');
  createIntroParticles(particlesContainer);

  // Start narrator voice automatically (will play after user gesture if blocked)
  playIntroNarration();

  // Transition function - now goes to LOGIN, not hologram
  const enterApp = () => {
    if (introLayer.classList.contains('exiting')) return;

    // Unlock audio context on user gesture (required for autoplay)
    unlockAudioContext();

    // If narrator was pending, try to play it now
    if (window.pendingNarrator) {
      window.pendingNarrator.play().catch(() => { });
      window.pendingNarrator = null;
    }

    // Add exit animation to intro
    introLayer.classList.add('exiting');

    // Fade out narrator audio smoothly
    if (narratorAudio && !narratorAudio.paused) {
      const fadeOut = setInterval(() => {
        if (narratorAudio.volume > 0.1) {
          narratorAudio.volume -= 0.1;
        } else {
          narratorAudio.pause();
          clearInterval(fadeOut);
        }
      }, 100);
    }

    // After intro exits, show login page
    setTimeout(() => {
      introLayer.style.display = 'none';

      // Check if already logged in
      if (isUserLoggedIn()) {
        initHologramAndApp();
      } else {
        showLoginPage();
      }
    }, 1200);
  };

  // Button click
  if (enterBtn) {
    enterBtn.addEventListener('click', enterApp);
  }

  // Space key trigger
  const handleKeyOrClick = (e) => {
    const buttonVisible = enterBtn && window.getComputedStyle(enterBtn).opacity !== '0';
    if (e.type === 'keydown' && e.code === 'Space' && buttonVisible) {
      e.preventDefault();
      enterApp();
      document.removeEventListener('keydown', handleKeyOrClick);
    }
  };

  document.addEventListener('keydown', handleKeyOrClick);
}

// ======================================
// LOGIN PAGE LOGIC
// ======================================
function isUserLoggedIn() {
  return localStorage.getItem('k1_authenticated') === 'true';
}

function showLoginPage() {
  const loginLayer = document.getElementById('k1LoginLayer');
  if (loginLayer) {
    loginLayer.style.display = 'flex';
  }
  initLoginHandlers();
}

function initLoginHandlers() {
  const loginForm = document.getElementById('k1LoginForm');
  const registerForm = document.getElementById('k1RegisterForm');
  const showRegisterBtn = document.getElementById('k1ShowRegisterBtn');
  const backToLoginBtn = document.getElementById('k1BackToLoginBtn');
  const useDemoBtn = document.getElementById('k1UseDemoBtn');
  const loginError = document.getElementById('k1LoginError');
  const demoHint = document.querySelector('.k1-demo-hint');
  const loginDivider = document.querySelector('.k1-login-divider');

  // Demo button click
  if (useDemoBtn) {
    useDemoBtn.addEventListener('click', () => {
      document.getElementById('loginUsername').value = 'demo';
      document.getElementById('loginPassword').value = 'demo';
      // Auto submit
      loginForm.dispatchEvent(new Event('submit'));
    });
  }

  // Toggle to register form
  if (showRegisterBtn) {
    showRegisterBtn.addEventListener('click', () => {
      loginForm.style.display = 'none';
      if (demoHint) demoHint.style.display = 'none';
      if (loginDivider) loginDivider.style.display = 'none';
      showRegisterBtn.style.display = 'none';
      registerForm.style.display = 'flex';
      hideLoginError();
    });
  }

  // Back to login
  if (backToLoginBtn) {
    backToLoginBtn.addEventListener('click', () => {
      registerForm.style.display = 'none';
      loginForm.style.display = 'flex';
      if (demoHint) demoHint.style.display = 'block';
      if (loginDivider) loginDivider.style.display = 'flex';
      showRegisterBtn.style.display = 'block';
      hideLoginError();
    });
  }

  // Login form submit
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('loginUsername').value.trim();
      const password = document.getElementById('loginPassword').value;

      if (!username || !password) {
        showLoginError('Please enter username and password');
        return;
      }

      const submitBtn = loginForm.querySelector('.k1-login-btn');
      submitBtn.classList.add('loading');
      hideLoginError();

      try {
        const result = await performLogin(username, password);

        if (result.success) {
          submitBtn.classList.remove('loading');
          submitBtn.classList.add('success');
          submitBtn.querySelector('.k1-btn-text').textContent = 'ACCESS GRANTED';

          // Store auth state
          localStorage.setItem('k1_authenticated', 'true');
          localStorage.setItem('k1_user', username);
          localStorage.setItem('k1_user_id', result.userId || username);

          // Transition to hologram
          setTimeout(() => {
            transitionToHologram();
          }, 800);
        } else {
          submitBtn.classList.remove('loading');
          showLoginError(result.error || 'Authentication failed');
        }
      } catch (err) {
        submitBtn.classList.remove('loading');
        showLoginError('Connection error. Please try again.');
        console.error('Login error:', err);
      }
    });
  }

  // Register form submit
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('registerUsername').value.trim();
      const email = document.getElementById('registerEmail').value.trim();
      const password = document.getElementById('registerPassword').value;
      const confirm = document.getElementById('registerConfirm').value;

      if (!username || !password) {
        showLoginError('Username and password are required');
        return;
      }

      if (password !== confirm) {
        showLoginError('Passwords do not match');
        return;
      }

      if (password.length < 4) {
        showLoginError('Password must be at least 4 characters');
        return;
      }

      const submitBtn = registerForm.querySelector('.k1-login-btn');
      submitBtn.classList.add('loading');
      hideLoginError();

      try {
        const result = await performRegister(username, password, email);

        if (result.success) {
          submitBtn.classList.remove('loading');
          submitBtn.classList.add('success');
          submitBtn.querySelector('.k1-btn-text').textContent = 'ACCOUNT CREATED';

          // Store auth state
          localStorage.setItem('k1_authenticated', 'true');
          localStorage.setItem('k1_user', username);
          localStorage.setItem('k1_user_id', result.userId || username);

          // Transition to hologram
          setTimeout(() => {
            transitionToHologram();
          }, 800);
        } else {
          submitBtn.classList.remove('loading');
          showLoginError(result.error || 'Registration failed');
        }
      } catch (err) {
        submitBtn.classList.remove('loading');
        showLoginError('Connection error. Please try again.');
        console.error('Register error:', err);
      }
    });
  }

  // Create particles for login page
  const loginParticles = document.getElementById('loginParticles');
  if (loginParticles) {
    createIntroParticles(loginParticles);
  }
}

async function performLogin(username, password) {
  // Demo user check (predefined)
  if (username === 'demo' && password === 'demo') {
    // Still call backend to register the session
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: 'demo', user: username, password: password })
      });
      const data = await res.json();
      return { success: true, userId: data.userId || 'demo' };
    } catch {
      // Even if backend fails, allow demo login
      return { success: true, userId: 'demo' };
    }
  }

  // Regular login via backend
  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: username, user: username, password: password })
    });

    if (!res.ok) {
      const data = await res.json();
      return { success: false, error: data.error || 'Invalid credentials' };
    }

    const data = await res.json();
    return { success: true, userId: data.userId || username };
  } catch (err) {
    console.error('Login API error:', err);
    return { success: false, error: 'Server connection failed' };
  }
}

async function performRegister(username, password, email) {
  try {
    // Use login endpoint to create/upsert user
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: username,
        user: username,
        password: password,
        email: email,
        isNewUser: true
      })
    });

    const data = await res.json();

    if (data.ok || data.userId) {
      return { success: true, userId: data.userId || username };
    }

    return { success: false, error: data.error || 'Registration failed' };
  } catch (err) {
    console.error('Register API error:', err);
    return { success: false, error: 'Server connection failed' };
  }
}

function showLoginError(message) {
  const errorEl = document.getElementById('k1LoginError');
  if (errorEl) {
    errorEl.textContent = message;
    errorEl.style.display = 'block';
  }
}

function hideLoginError() {
  const errorEl = document.getElementById('k1LoginError');
  if (errorEl) {
    errorEl.style.display = 'none';
  }
}

function transitionToHologram() {
  const loginLayer = document.getElementById('k1LoginLayer');
  const hologramMount = document.getElementById('hologramMount');
  const mainUI = document.getElementById('k1MainUI');

  if (loginLayer) {
    loginLayer.classList.add('exiting');
  }

  // Initialize hologram
  setTimeout(() => {
    initHologram();
  }, 200);

  // Reveal hologram
  setTimeout(() => {
    if (hologramMount) {
      hologramMount.style.opacity = '1';
      hologramMount.style.visibility = 'visible';
      hologramMount.classList.add('revealing');
    }
    setTimeout(() => {
      if (holo) holo.resize();
    }, 100);
  }, 400);

  // Reveal UI
  setTimeout(() => {
    if (mainUI) {
      mainUI.style.opacity = '1';
      mainUI.style.pointerEvents = 'auto';
      mainUI.classList.add('revealing');
    }
  }, 600);

  // Hide login and init main app
  setTimeout(() => {
    if (loginLayer) loginLayer.style.display = 'none';
    if (holo) holo.resize();
    initMainApp();
  }, 1200);
}

function initHologramAndApp() {
  const hologramMount = document.getElementById('hologramMount');
  const mainUI = document.getElementById('k1MainUI');

  // Initialize hologram directly
  initHologram();

  if (hologramMount) {
    hologramMount.style.opacity = '1';
    hologramMount.style.visibility = 'visible';
    hologramMount.classList.add('revealing');
  }

  if (mainUI) {
    mainUI.style.opacity = '1';
    mainUI.style.pointerEvents = 'auto';
    mainUI.classList.add('revealing');
  }

  setTimeout(() => {
    if (holo) holo.resize();
    initMainApp();
  }, 500);
}

function createIntroParticles(container) {
  if (!container) return;

  const particleCount = 25;

  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement('div');
    particle.className = 'k1-particle';

    // Random position and timing
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.animationDelay = `${Math.random() * 8}s`;
    particle.style.animationDuration = `${6 + Math.random() * 6}s`;

    // Random size variation
    const size = 2 + Math.random() * 4;
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;

    // Random color variation (cyan to purple spectrum)
    const hue = 180 + Math.random() * 60; // 180-240 (cyan to purple)
    particle.style.background = `hsla(${hue}, 100%, 70%, 0.7)`;
    particle.style.boxShadow = `0 0 ${size * 3}px hsla(${hue}, 100%, 60%, 0.8)`;

    container.appendChild(particle);
  }
}

// ======================================
// MAIN APP INITIALIZATION
// ======================================
function initMainApp() {
  initStatusBar();
  initTabs();

  // Bind send button
  const sendBtnEl = document.getElementById("btnSend");
  const micBtnEl = document.getElementById("btnMic");
  const textInputEl = document.getElementById("textInput");

  if (sendBtnEl) {
    sendBtnEl.onclick = () => sendText(textInputEl ? textInputEl.value : "");
  }

  if (textInputEl) {
    textInputEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendText(textInputEl.value);
      }
    });
  }

  if (micBtnEl) {
    micBtnEl.onclick = () => {
      if (!recording) startRecording();
      else stopRecording();
    };
  }

  // Auto login and welcome message
  setTimeout(async () => {
    await login();
    append("bot", "Hello! I'm Kelion. How can I help you today?");
  }, 500);

  loadPricing();
}

// ======================================
// DOM READY - Bootstrap Everything
// ======================================
document.addEventListener("DOMContentLoaded", () => {
  // Initialize viewport fit checker first (prevents scroll)
  initViewportFitChecker();

  // Initialize intro page (handles transition to main app)
  initIntroPage();

  // Initialize hologram early (it animates in background behind intro)
  // The hologram is hidden initially but rendering
});
