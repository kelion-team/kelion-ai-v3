// KELION GDPR/Privacy Panel
// Data privacy options and compliance information

window.loadGDPR = async function () {
    const dashView = document.getElementById('k1DashView');
    if (!dashView) return;

    const userId = localStorage.getItem('k1_user_id') || 'Unknown';

    dashView.innerHTML = `
    <div class="k1-gdpr-panel">
      <div class="k1-admin-header">
        <h3>🔒 PRIVACY & DATA OPTIONS</h3>
      </div>
      
      <div class="k1-gdpr-content">
        <div class="k1-privacy-section">
          <h4>📋 Your Data</h4>
          <div class="k1-data-info">
            <div class="k1-info-row">
              <span class="k1-info-label">Your User ID:</span>
              <span class="k1-info-value">${userId}</span>
            </div>
            <div class="k1-info-row">
              <span class="k1-info-label">Session ID:</span>
              <span class="k1-info-value">${localStorage.getItem('k1_session_id') || 'None'}</span>
            </div>
            <div class="k1-info-row">
              <span class="k1-info-label">Data Stored:</span>
              <span class="k1-info-value">Conversations, preferences, session logs</span>
            </div>
          </div>
        </div>

        <div class="k1-privacy-section">
          <h4>📜 Data Collection Notice</h4>
          <div class="k1-notice-box">
            <p><strong>What we collect:</strong></p>
            <ul>
              <li>💬 Chat messages and responses</li>
              <li>🔊 Voice recordings (for STT, not stored permanently)</li>
              <li>📊 Usage analytics and session data</li>
              <li>⚙️ Preferences and settings</li>
            </ul>
            <p><strong>Why we collect it:</strong></p>
            <ul>
              <li>To provide personalized AI responses</li>
              <li>To maintain conversation context</li>
              <li>To improve our services</li>
              <li>For audit and compliance purposes</li>
            </ul>
          </div>
        </div>

        <div class="k1-privacy-section">
          <h4>🛡️ Your Rights (GDPR)</h4>
          <div class="k1-rights-grid">
            <div class="k1-right-card">
              <div class="k1-right-icon">📥</div>
              <div class="k1-right-title">Data Export</div>
              <div class="k1-right-desc">Request a copy of all data associated with your account</div>
              <button class="k1-btn-outline" onclick="requestDataExport()">Request Export</button>
            </div>
            <div class="k1-right-card">
              <div class="k1-right-icon">🗑️</div>
              <div class="k1-right-title">Data Deletion</div>
              <div class="k1-right-desc">Request permanent deletion of your data</div>
              <button class="k1-btn-danger" onclick="requestDataDeletion()">Request Deletion</button>
            </div>
            <div class="k1-right-card">
              <div class="k1-right-icon">✏️</div>
              <div class="k1-right-title">Data Rectification</div>
              <div class="k1-right-desc">Correct inaccurate personal data</div>
              <button class="k1-btn-outline" onclick="requestRectification()">Contact Support</button>
            </div>
            <div class="k1-right-card">
              <div class="k1-right-icon">⏸️</div>
              <div class="k1-right-title">Processing Restriction</div>
              <div class="k1-right-desc">Limit how we use your data</div>
              <button class="k1-btn-outline" onclick="requestRestriction()">Request Restriction</button>
            </div>
          </div>
        </div>

        <div class="k1-privacy-section">
          <h4>🔗 Legal Documents</h4>
          <div class="k1-legal-links">
            <a href="#" class="k1-legal-link" onclick="showPolicy('privacy')">
              <span>📄</span> Privacy Policy
            </a>
            <a href="#" class="k1-legal-link" onclick="showPolicy('terms')">
              <span>📄</span> Terms of Service
            </a>
            <a href="#" class="k1-legal-link" onclick="showPolicy('cookies')">
              <span>🍪</span> Cookie Policy
            </a>
            <a href="#" class="k1-legal-link" onclick="showPolicy('dpa')">
              <span>🤝</span> Data Processing Agreement
            </a>
          </div>
        </div>

        <div class="k1-privacy-section k1-contact-dpo">
          <h4>📞 Contact Data Protection Officer</h4>
          <p>For any privacy-related inquiries:</p>
          <a href="mailto:privacy@kelionai.app" class="k1-btn-primary">
            ✉️ privacy@kelionai.app
          </a>
        </div>
      </div>
    </div>
  `;
};

window.requestDataExport = function () {
    const userId = localStorage.getItem('k1_user_id');
    const confirmed = confirm(
        `Request data export for User ID: ${userId}?\n\n` +
        `We will prepare a complete export of all your data and send it to your registered email within 30 days.`
    );

    if (confirmed) {
        fetch('/api/contact_submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: 'GDPR Export Request',
                email: 'pending',
                message: `Data Export Request for User ID: ${userId}`
            })
        }).then(() => {
            alert('✅ Export request submitted. You will be contacted within 30 days.');
        }).catch(() => {
            alert('❌ Failed to submit request. Please email privacy@kelionai.app directly.');
        });
    }
};

window.requestDataDeletion = function () {
    const userId = localStorage.getItem('k1_user_id');
    const confirmed = confirm(
        `⚠️ WARNING: Data Deletion Request\n\n` +
        `This will request PERMANENT deletion of ALL data associated with User ID: ${userId}\n\n` +
        `This cannot be undone. Are you sure?`
    );

    if (confirmed) {
        const doubleConfirm = confirm(
            `Please confirm again.\n\n` +
            `Type "DELETE" in the next prompt to confirm deletion request.`
        );

        if (doubleConfirm) {
            const typed = prompt('Type DELETE to confirm:');
            if (typed === 'DELETE') {
                fetch('/api/contact_submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: 'GDPR Deletion Request',
                        email: 'pending',
                        message: `Data Deletion Request for User ID: ${userId}`
                    })
                }).then(() => {
                    alert('✅ Deletion request submitted. Your data will be removed within 30 days.');
                    localStorage.clear();
                }).catch(() => {
                    alert('❌ Failed to submit request. Please email privacy@kelionai.app directly.');
                });
            }
        }
    }
};

window.requestRectification = function () {
    window.location.href = 'mailto:privacy@kelionai.app?subject=Data%20Rectification%20Request';
};

window.requestRestriction = function () {
    const confirmed = confirm(
        'Request processing restriction?\n\n' +
        'This will limit how KELION uses your data. You may experience reduced functionality.'
    );

    if (confirmed) {
        alert('✅ Restriction request noted. Contact privacy@kelionai.app for immediate action.');
    }
};

window.showPolicy = function (type) {
    const policies = {
        privacy: 'Privacy Policy - Full document available at /legal/privacy',
        terms: 'Terms of Service - Full document available at /legal/terms',
        cookies: 'Cookie Policy - We use essential cookies only for session management.',
        dpa: 'Data Processing Agreement - Available for enterprise customers upon request.'
    };

    alert(policies[type] || 'Document not found');
};

// Make globally available
if (typeof window.app === 'undefined') window.app = {};
window.app.loadGDPR = window.loadGDPR;
