// KELION Users Panel - User Management
// Displays user statistics and management options

window.loadUsers = async function () {
    const dashView = document.getElementById('k1DashView');
    if (!dashView) return;

    dashView.innerHTML = `
    <div class="k1-users-panel">
      <div class="k1-admin-header">
        <h3>👥 USER MANAGEMENT</h3>
        <button class="k1-btn-refresh" onclick="loadUsers()">⟳ Refresh</button>
      </div>
      <div id="usersContent" class="k1-users-content">
        <div class="k1-loading">
          <div class="k1-spinner"></div>
          <span>Loading user data...</span>
        </div>
      </div>
    </div>
  `;

    try {
        // First get dashboard stats
        const dashRes = await fetch('/api/dashboard');
        const dashData = await dashRes.json();

        const content = document.getElementById('usersContent');

        content.innerHTML = `
      <div class="k1-stats-grid">
        <div class="k1-stat-card">
          <div class="k1-stat-icon">👤</div>
          <div class="k1-stat-value">${dashData.users || 0}</div>
          <div class="k1-stat-label">Total Users</div>
        </div>
        <div class="k1-stat-card">
          <div class="k1-stat-icon">💬</div>
          <div class="k1-stat-value">${dashData.messages || 0}</div>
          <div class="k1-stat-label">Total Messages</div>
        </div>
        <div class="k1-stat-card">
          <div class="k1-stat-icon">📧</div>
          <div class="k1-stat-value">${dashData.leads || 0}</div>
          <div class="k1-stat-label">Leads</div>
        </div>
        <div class="k1-stat-card">
          <div class="k1-stat-icon">🔧</div>
          <div class="k1-stat-value">${dashData.version || 'k1.0.0'}</div>
          <div class="k1-stat-label">Version</div>
        </div>
      </div>
      
      <div class="k1-users-section">
        <h4>📊 User Lookup</h4>
        <div class="k1-user-search">
          <input type="text" id="userIdInput" class="k1-input" placeholder="Enter User ID...">
          <button class="k1-btn-primary" onclick="lookupUser()">Search</button>
        </div>
        <div id="userLookupResult"></div>
      </div>

      <div class="k1-users-section">
        <h4>📋 Subscription Tiers</h4>
        <div class="k1-tiers-grid">
          <div class="k1-tier-card k1-tier-starter">
            <div class="k1-tier-name">STARTER</div>
            <div class="k1-tier-price">$19/mo</div>
            <ul>
              <li>50 messages/day</li>
              <li>Web hologram</li>
              <li>AI chat</li>
              <li>Basic support</li>
            </ul>
          </div>
          <div class="k1-tier-card k1-tier-pro">
            <div class="k1-tier-name">PRO</div>
            <div class="k1-tier-price">$59/mo</div>
            <ul>
              <li>500 messages/day</li>
              <li>Voice (TTS/STT)</li>
              <li>Persistent memory</li>
              <li>Admin audit</li>
            </ul>
          </div>
          <div class="k1-tier-card k1-tier-enterprise">
            <div class="k1-tier-name">ENTERPRISE</div>
            <div class="k1-tier-price">$199/mo</div>
            <ul>
              <li>Unlimited messages</li>
              <li>Custom workflows</li>
              <li>Legal-grade audit</li>
              <li>SLA guarantee</li>
            </ul>
          </div>
        </div>
      </div>
    `;
    } catch (e) {
        document.getElementById('usersContent').innerHTML = `
      <div class="k1-error">
        <p>Failed to load user data</p>
        <small>${e.message}</small>
      </div>
    `;
    }
};

window.lookupUser = async function () {
    const userId = document.getElementById('userIdInput')?.value?.trim();
    const resultDiv = document.getElementById('userLookupResult');

    if (!userId || !resultDiv) return;

    const adminToken = localStorage.getItem('k1_admin_token');
    if (!adminToken) {
        resultDiv.innerHTML = '<div class="k1-error">Admin token required. Go to Admin panel first.</div>';
        return;
    }

    resultDiv.innerHTML = '<div class="k1-loading"><div class="k1-spinner"></div></div>';

    try {
        const res = await fetch(`/admin/messages?user_id=${encodeURIComponent(userId)}&limit=20`, {
            headers: { 'X-Admin-Token': adminToken }
        });

        if (!res.ok) throw new Error('Unauthorized');

        const data = await res.json();

        if (!data.items || data.items.length === 0) {
            resultDiv.innerHTML = '<div class="k1-empty">No messages found for this user</div>';
            return;
        }

        resultDiv.innerHTML = `
      <div class="k1-user-messages">
        <h5>Recent Messages for ${data.user_id}</h5>
        ${data.items.slice(0, 10).map(m => `
          <div class="k1-message-preview ${m.role}">
            <span class="k1-msg-role">${m.role === 'user' ? '👤' : '🤖'}</span>
            <span class="k1-msg-content">${m.content?.slice(0, 100) || '-'}${m.content?.length > 100 ? '...' : ''}</span>
            <span class="k1-msg-time">${new Date(m.created_at).toLocaleTimeString()}</span>
          </div>
        `).join('')}
      </div>
    `;
    } catch (e) {
        resultDiv.innerHTML = `<div class="k1-error">Error: ${e.message}</div>`;
    }
};

// Make globally available
if (typeof window.app === 'undefined') window.app = {};
window.app.loadUsers = window.loadUsers;
